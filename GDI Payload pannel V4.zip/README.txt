You can change these mp3 files out just make sure to name them the same things as original or else they won't play

" AUDIO WON'T WORK UNLESS FOLDER EXTRACTED "

Credits to PRGBQUAD-370 from github.com